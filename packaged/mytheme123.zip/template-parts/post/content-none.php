<p><?php echo apply_filters('mytheme123_no_posts_text', esc_html('Sorry, no posts matched your criteria.', 'mytheme123')); ?></p>
