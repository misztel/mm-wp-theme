<p><?php echo apply_filters('mytheme_no_posts_text', esc_html('Sorry, no posts matched your criteria.', 'mytheme')); ?></p>
