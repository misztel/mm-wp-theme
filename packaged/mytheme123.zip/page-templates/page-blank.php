<?php
/*
Template Name: Blank
*/
get_header(); ?>


<main role="main">
  <?php get_template_part('loop', 'page'); ?>
</main>

<?php get_footer(); ?>
