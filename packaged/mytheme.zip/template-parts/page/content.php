<article <?php post_class('mb-4 p-3 bg-white'); ?>>

  <header>
    <h1 class="page-title">
      <?php the_title(); ?>
    </h1>
  </header>
  <div class="page-content">
    <?php the_content(); ?>
  </div>
</article>
