wp.blocks.registerBlockStyle('core/heading', {
  name: 'mytheme123-heading',
  label: 'mytheme123 Heading',
});
