<?php get_header(); ?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <main role="main">
        <div class="container">
          <div class="row">
            <?php get_template_part('loop', 'index'); ?>
          </div>
        </div>
      </main>
    </div>
  </div>
</div>
<?php get_footer(); ?>
