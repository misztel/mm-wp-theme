wp.blocks.registerBlockStyle('core/group', {
  name: 'mytheme123-group',
  label: 'mytheme123 Group',
});
